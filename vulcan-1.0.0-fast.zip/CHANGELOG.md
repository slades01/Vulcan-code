# Changelog

All notable changes to this package are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/) and this project adheres to
[Semantic Versioning](https://semver.org/) (with an `-fast` pre-release suffix tracking the
opencode runtime).

## [1.0.0-vulcan.0] - 2026-06-25

### Changed
- Rebranded the public package as **VulcanCode**, launched via the `vulcan` command. User-facing
  docs, package metadata, scripts, smoke tests, and the release archive now say VulcanCode/`vulcan`
  instead of opencode.
- New release archive `vulcan-1.0.0-fast.zip` (forward-slash entries). The previous
  `opencode-1.0.0-fast.zip` is removed from the current tree but retained in git history.
- `npm run config:health` and the documented smoke tests now run `vulcan --version` /
  `vulcan debug ...`.
- Renamed the `opencode-maintainer` agent to `vulcan-maintainer` and updated its references.
- Branding cleanup of residual opencode-derived names: the laptop workhorse recovery paths
  (`~\opencode-workhorse\` → `~\vulcan-workhorse\`) and benchmark script
  (`benchmark_opencode_workhorse.py` → `benchmark_vulcan_workhorse.py`) in
  `command/laptop-research.md` and `skills/laptop-research-workhorse/SKILL.md` now use
  Vulcan-branded names (recovery-only / unavailable status and `laptop-gemma/*` provider IDs
  are preserved).
- `examples/quickstart.md` no longer links VulcanCode to `https://opencode.ai`; the opencode
  install docs are referenced only as the underlying runtime.
- `package.json` metadata key `opencode` renamed to a Vulcan-branded `vulcan` object; the
  `@opencode-ai/plugin` dependency is unchanged.
- `README.md` adds a preserved-identifiers note clarifying that `opencode-go/...` provider/model
  IDs are intentional provider identifiers, not stale branding.

### Preserved (intentional technical references)
- Config schema URL `https://opencode.ai/config.json` and the `@opencode-ai/plugin` SDK —
  VulcanCode uses the opencode config schema and plugin SDK under the hood.
- Config file/dir names the runtime loads: `opencode.jsonc`, `config/opencode.example.jsonc`,
  `~/.config/opencode`, `.opencode/`.
- `opencode-go/...` provider/model IDs (panel agents) and `laptop-gemma/*` provider IDs —
  registered provider identifiers, not stale branding.

## [1.0.0-fast] - 2026-06-25

### Added
- Initial public release of the Vulcan-code opencode configuration package.
- 33 agents (`agent/`), 26 commands (`command/`), 8 skills (`skills/`).
- TypeScript plugins `trusted-autonomy.ts` and `swarm-compaction.ts` (`plugins/`).
- Guard tools `loop_guard.ts` and `pace_guard.ts` (`tools/`).
- Benchmark suite (`bench/`) and spec workflow docs (`spec/`).
- `config/opencode.example.jsonc` placeholder config, `examples/` walk-throughs.
- Top-level `README.md`, `SECURITY.md`, `LICENSE` (MIT), `package.json`, `tsconfig.json`.
- Downloadable archive `opencode-1.0.0-fast.zip`.

### Security
- Sanitized of all local absolute paths, private hostnames, LAN host information, and
  per-user paths.
- Excluded the raw key-bearing config, usage/billing ledger, private host access, project
  and memory notes, handoffs, local backups, dependency install output, lockfiles, logs, and
  caches.
- Verified zero secret material via blocked-pattern and broader secret scans.
